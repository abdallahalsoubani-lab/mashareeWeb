/**
 * Project Details Page - Complete Version
 * Based on provided screenshots
 */

'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import RiyalSymbol from '@/components/ui/RiyalSymbol';
import {
  MapPin,
  TrendingUp,
  Calendar,
  DollarSign,
  ChevronRight,
  Building2,
  Users,
  Shield,
  FileText,
  Download,
  ChevronDown,
  Clock,
  Percent,
  Home,
  PieChart,
  CheckCircle,
} from 'lucide-react';

interface Project {
  id: string;
  title: string;
  type: string;
  description: string;
  location: string;
  image: string;
  images: string[];
  badges: string[];
  fundedAmount: number;
  targetAmount: number;
  expectedReturn: number;
  durationMonths: number;
  minimumAmount: number;
  unitPrice: number;
  riskLevel: string;
  category: string;
  fundManager: string;
  distributor: string;
  supervisor: string;
  distributionPolicy: string;
  status: string;
  latitude: number;
  longitude: number;
  boardMembers: any;
  attachments: any;
}

const toArabicNumeral = (num: string | number) => {
  const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(num).replace(/\d/g, (digit) => arabicNumerals[parseInt(digit)]);
};

export default function ProjectDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [selectedImage, setSelectedImage] = useState(0);
  const [projectId, setProjectId] = useState<string>('');
  const [showConfirmPopup, setShowConfirmPopup] = useState(false);
  const [investing, setInvesting] = useState(false);
  const [investmentSuccess, setInvestmentSuccess] = useState(false);

  useEffect(() => {
    const unwrapParams = async () => {
      const resolvedParams = await params;
      setProjectId(resolvedParams.id);
    };
    unwrapParams();
  }, [params]);

  useEffect(() => {
    if (!projectId) return;
    
    const fetchProject = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/projects/${projectId}`);
        const data = await response.json();

        if (data.success) {
          setProject(data.project);
          setInvestmentAmount(data.project.minimumAmount.toString());
        } else {
          setError(data.error || 'فشل تحميل المشروع');
        }
      } catch (err) {
        setError('فشل الاتصال بالخادم');
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchProject();
  }, [projectId]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA').format(amount);
  };

  const calculateReturns = () => {
    if (!project || !investmentAmount) return { total: 0, monthly: 0 };
    const amount = parseFloat(investmentAmount);
    const totalReturn = (amount * project.expectedReturn * project.durationMonths) / (12 * 100);
    const monthlyReturn = totalReturn / project.durationMonths;
    return { total: totalReturn, monthly: monthlyReturn };
  };

  const returns = calculateReturns();

  const handleInvestment = async () => {
    if (!project) return;
    
    try {
      setInvesting(true);
      const response = await fetch('/api/investments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          amount: parseFloat(investmentAmount),
        }),
      });

      const data = await response.json();

      if (data.success) {
        setInvestmentSuccess(true);
        setShowConfirmPopup(false);
        // Refresh project data
        const projectResponse = await fetch(`/api/projects/${projectId}`);
        const projectData = await projectResponse.json();
        if (projectData.success) {
          setProject(projectData.project);
        }
      } else {
        alert(data.error || 'فشل إضافة الاستثمار');
      }
    } catch (error) {
      console.error('Error investing:', error);
      alert('حدث خطأ في إضافة الاستثمار');
    } finally {
      setInvesting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-mesh flex items-center justify-center">
        <div className="text-center animate-fade-in-scale">
          <div className="relative mx-auto mb-6">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-primary-500/20 border-t-primary-500" />
            <div className="absolute inset-0 rounded-full bg-primary-500/20 blur-xl animate-pulse" />
          </div>
          <p className="text-text-secondary text-lg font-medium">جاري تحميل تفاصيل المشروع...</p>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-mesh flex items-center justify-center">
        <div className="text-center glass p-8 rounded-3xl border border-primary/30 max-w-md">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-500/10 flex items-center justify-center">
            <span className="text-3xl">⚠️</span>
          </div>
          <p className="text-red-400 font-semibold mb-6 text-lg">{error || 'فشل تحميل المشروع'}</p>
          <Link 
            href="/projects" 
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-background font-bold rounded-xl hover:shadow-glow-gold transition-all hover:scale-105"
          >
            العودة إلى الصناديق
          </Link>
        </div>
      </div>
    );
  }

  const progress = (project.fundedAmount / project.targetAmount) * 100;
  const allImages = [project.image, ...(project.images || [])];

  return (
    <div className="min-h-screen bg-mesh pb-16">
      {/* Top Navigation with glass effect */}
      <div className="glass border-b-2 border-primary/30 px-4 md:px-6 py-4 sticky top-16 z-20 shadow-lg animate-fade-in-up">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-sm">
            <Link 
              href="/projects" 
              className="text-text-muted hover:text-primary-400 flex items-center gap-1 font-semibold transition-colors"
            >
              الصناديق الاستثمارية
            </Link>
            <ChevronRight size={16} className="text-text-dimmed" />
            <span className="text-text-primary font-bold line-clamp-1">{project.title}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header Card with Badges */}
            <div className="group relative animate-fade-in-scale">
              <div className="absolute -inset-0.5 bg-primary rounded-2xl opacity-0 group-hover:opacity-15 blur-xl transition-all duration-500" />
              <div className="relative glass rounded-2xl p-6 md:p-8 border-2 border-primary/70 group-hover:border-primary transition-all duration-300 shadow-card group-hover:shadow-card-hover">
                {/* Type Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-background-tertiary rounded-full text-sm font-bold mb-4 border border-primary/30 text-primary">
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  {project.type}
                </div>

                {/* Badges */}
                {project.badges && project.badges.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.badges.map((badge, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1.5 glass rounded-full text-xs font-bold border border-primary/30 text-primary-400"
                      >
                        {badge}
                      </span>
                    ))}
                  </div>
                )}

                <h1 className="text-2xl md:text-4xl font-bold text-primary mb-4">
                  {project.title}
                </h1>

                <p className="text-text-secondary text-base md:text-lg mb-4 leading-relaxed">
                  {project.description || 'وصف المشروع سيتم إضافته قريباً'}
                </p>

                <div className="flex items-center gap-2 text-text-primary">
                  <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                    <MapPin className="text-primary-400" size={20} />
                  </div>
                  <span className="font-semibold">{project.location}</span>
                </div>
              </div>
            </div>

            {/* Image Gallery */}
            <div className="group relative animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <div className="absolute -inset-0.5 bg-primary rounded-2xl opacity-0 group-hover:opacity-15 blur-xl transition-all duration-500" />
              <div className="relative glass rounded-2xl overflow-hidden border-2 border-primary/70 group-hover:border-primary transition-all duration-300 shadow-card group-hover:shadow-card-hover">
                {/* Main Image */}
                <div className="relative h-96 bg-background-tertiary overflow-hidden">
                  <img
                    src={allImages[selectedImage]}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/50 to-transparent" />
                  {allImages.length > 1 && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 glass px-3 py-2 rounded-full border border-primary/20">
                      {allImages.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSelectedImage(idx)}
                          className={`h-2 rounded-full transition-all ${
                            selectedImage === idx 
                              ? 'bg-primary w-8' 
                              : 'bg-text-dimmed/50 w-2 hover:bg-text-dimmed'
                          }`}
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* Thumbnail Strip */}
                {allImages.length > 1 && (
                  <div className="flex gap-3 p-4 overflow-x-auto">
                    {allImages.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedImage(idx)}
                        className={`relative flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                          selectedImage === idx 
                            ? 'border-primary-500 shadow-glow-sm' 
                            : 'border-primary/20 hover:border-primary/40'
                        }`}
                      >
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        {selectedImage === idx && (
                          <div className="absolute inset-0 bg-primary-500/20 border-2 border-primary-500" />
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* التفاصيل - Details Section */}
            <div className="group relative animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
              <div className="absolute -inset-0.5 bg-primary rounded-2xl opacity-0 group-hover:opacity-15 blur-xl transition-all duration-500" />
              <div className="relative glass rounded-2xl p-6 md:p-8 border-2 border-primary/70 group-hover:border-primary transition-all duration-300 shadow-card group-hover:shadow-card-hover">
                <h2 className="text-2xl md:text-3xl font-bold text-text-primary mb-6 flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-primary shadow-glow-sm">
                    <FileText className="text-white drop-shadow-lg" size={24} />
                  </div>
                  <span className="drop-shadow-lg">التفاصيل</span>
                </h2>

              {/* Fund Structure */}
              <div className="mb-8">
                <h3 className="text-xl font-bold text-text-primary mb-4">هيكل الصندوق</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                    <p className="text-text-muted text-sm mb-2">حجم الصندوق المستهدف</p>
                    <p className="text-xl font-bold text-text-primary flex items-center gap-2 drop-shadow-lg">
                      {formatCurrency(project.targetAmount)} <RiyalSymbol size={18} className="text-primary-400 drop-shadow-lg" />
                    </p>
                  </div>
                  <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                    <p className="text-text-muted text-sm mb-2">تغطية عملاء منصة صخر</p>
                    <p className="text-xl font-bold text-primary drop-shadow-lg">
                      {Math.round(progress)}%
                    </p>
                  </div>
                </div>
              </div>

              {/* Parties */}
              <div className="mb-8">
                <h3 className="text-xl font-bold text-text-primary mb-4">الأطراف ذات العلاقة</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="glass p-4 rounded-xl border-2 border-primary/60 hover:border-primary transition-all shadow-input hover:shadow-card">
                    <p className="text-text-muted text-sm mb-3">مدير الصندوق</p>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                        <Building2 size={18} className="text-primary-400" />
                      </div>
                      <p className="font-bold text-text-primary">{project.fundManager || 'غير محدد'}</p>
                    </div>
                  </div>

                  <div className="glass p-4 rounded-xl border-2 border-primary/60 hover:border-primary transition-all shadow-input hover:shadow-card">
                    <p className="text-text-muted text-sm mb-3">موزع الوحدات</p>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                        <Building2 size={18} className="text-primary" />
                      </div>
                      <p className="font-bold text-text-primary">{project.distributor || 'غير محدد'}</p>
                    </div>
                  </div>

                  <div className="glass p-4 rounded-xl border-2 border-primary/60 hover:border-primary transition-all shadow-input hover:shadow-card">
                    <p className="text-text-muted text-sm mb-3">الرقابة</p>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                        <Shield size={18} className="text-primary" />
                      </div>
                      <p className="font-bold text-text-primary">{project.supervisor}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Location Map */}
              {project.latitude && project.longitude && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-text-primary mb-4">الموقع</h3>
                  <div className="aspect-video bg-background-tertiary rounded-xl overflow-hidden border border-primary/20">
                    <iframe
                      src={`https://maps.google.com/maps?q=${project.latitude},${project.longitude}&hl=ar&z=14&output=embed`}
                      className="w-full h-full border-0"
                      loading="lazy"
                    />
                  </div>
                  <p className="text-text-secondary text-sm mt-3 flex items-center gap-2 glass p-3 rounded-lg border border-primary/10 w-fit">
                    <MapPin size={16} className="text-primary-400" />
                    {project.location}
                  </p>
                </div>
              )}

              {/* Board Members */}
              {project.boardMembers && typeof project.boardMembers === 'object' && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-text-primary mb-4">أعضاء مجلس الإدارة</h3>
                  <div className="space-y-3">
                    {Object.entries(project.boardMembers).map(([key, member]: [string, any], idx) => (
                      <div key={idx} className="flex items-center gap-4 glass p-4 rounded-xl border border-primary/10 hover:border-primary/30 transition-all">
                        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0 shadow-glow-gold">
                          <Users size={20} className="text-white" />
                        </div>
                        <div>
                          <p className="font-bold text-text-primary">{member.name}</p>
                          <p className="text-text-muted text-sm">{member.role}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Attachments / Documents */}
              <div>
                <h3 className="text-xl font-bold text-text-primary mb-4">المرفقات</h3>
                <div className="space-y-3">
                  <div className="group relative">
                    <div className="absolute -inset-0.5 bg-primary rounded-xl opacity-0 group-hover:opacity-10 blur transition-all duration-300" />
                    <div className="relative flex items-center justify-between p-4 glass rounded-xl border-2 border-primary/60 hover:border-primary transition-all cursor-pointer shadow-input hover:shadow-card">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                          <FileText className="text-primary-400" size={20} />
                        </div>
                        <div>
                          <p className="font-semibold text-text-primary">شروط وأحكام صندوق تنمية الفرص.pdf</p>
                          <p className="text-text-muted text-xs">PDF • 2.5 MB</p>
                        </div>
                      </div>
                      <button className="px-4 py-2 glass border border-primary/20 hover:border-primary/40 text-primary-400 hover:text-primary-300 text-sm font-bold rounded-lg transition-all hover:shadow-glow-sm">
                        عرض الملف
                      </button>
                    </div>
                  </div>

                  <div className="group relative">
                    <div className="absolute -inset-0.5 bg-primary rounded-xl opacity-0 group-hover:opacity-10 blur transition-all duration-300" />
                    <div className="relative flex items-center justify-between p-4 glass rounded-xl border-2 border-primary/60 hover:border-primary transition-all cursor-pointer shadow-input hover:shadow-card">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                          <FileText className="text-primary-400" size={20} />
                        </div>
                        <div>
                          <p className="font-semibold text-text-primary">صندوق تنمية الفرص - الملخص التنفيذي.pdf</p>
                          <p className="text-text-muted text-xs">PDF • 1.8 MB</p>
                        </div>
                      </div>
                      <button className="px-4 py-2 glass border border-primary/20 hover:border-primary/40 text-primary-400 hover:text-primary-300 text-sm font-bold rounded-lg transition-all hover:shadow-glow-sm">
                        عرض الملف
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Right Side */}
          <div className="space-y-6">
            {/* Chart/Stats Card - Moved to top */}
            <div className="group relative animate-fade-in-scale" style={{ animationDelay: '0.3s' }}>
              <div className="absolute -inset-1 bg-primary rounded-2xl opacity-20 blur-2xl group-hover:opacity-35 transition-all duration-700" />
              <div className="relative glass rounded-2xl p-8 border-2 border-primary/30 group-hover:border-primary/50 transition-all duration-300 shadow-glow-sm overflow-visible">
                <h3 className="text-lg font-bold text-text-primary mb-6 flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-primary shadow-glow-gold">
                    <PieChart size={18} className="text-white" />
                  </div>
                  <span>مخطط هيكل الصندوق</span>
                </h3>
                
                <div className="flex items-center justify-center py-6">
                  <div className="relative w-48 h-48">
                    {/* Enhanced Donut Chart with multiple layers - مصغر */}
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 224 224">
                      {/* Background shadow circle */}
                      <circle
                        cx="112"
                        cy="112"
                        r="85"
                        fill="none"
                        stroke="rgba(10, 14, 26, 0.8)"
                        strokeWidth="30"
                      />
                      {/* Main progress circle */}
                      <circle
                        cx="112"
                        cy="112"
                        r="85"
                        fill="none"
                        stroke="#8F7F5E"
                        strokeWidth="30"
                        strokeDasharray={`${(progress / 100) * 534.07} 534.07`}
                        strokeLinecap="round"
                        style={{
                          filter: 'drop-shadow(0 0 6px rgba(143, 127, 94, 0.6))',
                          transition: 'all 1s ease-in-out'
                        }}
                      />
                      {/* Inner glow effect */}
                      <circle
                        cx="112"
                        cy="112"
                        r="85"
                        fill="none"
                        stroke="#af9f77"
                        strokeWidth="3"
                        strokeDasharray={`${(progress / 100) * 534.07} 534.07`}
                        strokeLinecap="round"
                        opacity="0.6"
                      />
                    </svg>
                    
                    {/* Center content with enhanced styling - مصغر */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="relative">
                        <div className="absolute -inset-3 bg-primary/20 rounded-full blur-lg" />
                        <p className="relative text-4xl font-black text-primary mb-1">
                          {Math.round(progress)}%
                        </p>
                      </div>
                      <p className="text-text-muted text-xs font-medium text-center px-3 max-w-[100px]">
                        تغطية عملاء منصة صخر
                      </p>
                    </div>
                  </div>
                </div>

                {/* Legend/Stats below chart - مصغر */}
                <div className="mt-4 pt-4 border-t border-primary/30 grid grid-cols-2 gap-3">
                  <div className="glass p-2.5 rounded-xl border-2 border-primary/60 shadow-input">
                    <p className="text-text-muted text-[10px] mb-0.5">المبلغ المجموع</p>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 drop-shadow-lg">
                      {formatCurrency(project.fundedAmount)} <RiyalSymbol size={10} />
                    </p>
                  </div>
                  <div className="glass p-2.5 rounded-xl border-2 border-primary/60 shadow-input">
                    <p className="text-text-muted text-[10px] mb-0.5">المبلغ المستهدف</p>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 drop-shadow-lg">
                      {formatCurrency(project.targetAmount)} <RiyalSymbol size={10} />
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Investment Calculator Card */}
            <div className="group relative animate-fade-in-scale" style={{ animationDelay: '0.4s' }}>
              <div className="absolute -inset-1 bg-primary rounded-2xl opacity-0 group-hover:opacity-20 blur-2xl transition-all duration-700" />
              <div className="relative glass rounded-2xl p-6 border-2 border-primary/40 group-hover:border-primary transition-all duration-300 shadow-card group-hover:shadow-card-hover">
                {/* Type Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-background-tertiary rounded-full text-sm font-bold mb-4 border border-primary/30 text-primary">
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  صندوق ملكية خاصة
                </div>

                <h2 className="text-2xl font-bold text-primary mb-6">
                  {project.title}
                </h2>

                {/* Progress Bar */}
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-text-muted text-sm font-medium">نسبة التغطية</span>
                    <span className="text-2xl font-bold text-primary">
                      {Math.round(progress)}%
                    </span>
                  </div>
                  <div className="relative w-full h-3 bg-background-tertiary rounded-full overflow-hidden border-2 border-primary/50 shadow-input">
                    <div
                      className="absolute inset-0 bg-primary rounded-full transition-all duration-700 shadow-glow-sm"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

              {/* Amounts */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                  <p className="text-text-muted text-xs mb-2">نقطة مشاريع</p>
                  <p className="text-lg font-bold text-text-primary drop-shadow-lg">
                    {formatCurrency(project.fundedAmount)}
                  </p>
                </div>
                <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                  <p className="text-text-muted text-xs mb-2">مدير الصندوق</p>
                  <p className="text-lg font-bold text-text-primary">
                    {formatCurrency(project.targetAmount - project.fundedAmount)}
                  </p>
                </div>
              </div>

              {/* Key Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 mb-6 pb-6 border-b border-primary/20">
                <div className="text-center p-4 glass rounded-xl border-2 border-accent-teal/60 hover:border-accent-teal transition-all shadow-input hover:shadow-card">
                  <p className="text-text-muted text-xs mb-2">سعر الوحدة</p>
                  <p className="text-lg font-bold text-accent-teal flex items-center justify-center gap-1 drop-shadow-lg">
                    {formatCurrency(project.unitPrice || project.minimumAmount)} <RiyalSymbol size={16} />
                  </p>
                </div>
                <div className="text-center p-4 glass rounded-xl border-2 border-primary/60 hover:border-primary transition-all shadow-input hover:shadow-card">
                  <p className="text-text-muted text-xs mb-2">مدة الفرصة</p>
                  <p className="text-lg font-bold text-text-primary flex items-center justify-center gap-1 drop-shadow-lg">
                    <Clock size={16} className="text-primary-400 drop-shadow-lg" />
                    {project.durationMonths} شهر
                  </p>
                </div>
                <div className="text-center p-4 glass rounded-xl border-2 border-accent-green/60 hover:border-accent-green transition-all shadow-input hover:shadow-card">
                  <p className="text-text-muted text-xs mb-2">نصائح العائد للمستثمار</p>
                  <p className="text-lg font-bold text-accent-green flex items-center justify-center gap-1 drop-shadow-lg">
                    <TrendingUp size={16} />
                    {project.expectedReturn}%
                  </p>
                </div>
                <div className="text-center p-4 glass rounded-xl border-2 border-accent-purple/60 hover:border-accent-purple transition-all shadow-input hover:shadow-card">
                  <p className="text-text-muted text-xs mb-2">الحد الأدنى للاستثمار</p>
                  <p className="text-lg font-bold text-accent-purple flex items-center justify-center gap-1 drop-shadow-lg">
                    {formatCurrency(project.minimumAmount)} <RiyalSymbol size={14} />
                  </p>
                </div>
              </div>

              {/* Distribution Policy */}
              <div className="mb-6 space-y-3">
                <div className="flex items-center justify-between p-4 glass rounded-xl border-2 border-primary/60 shadow-input">
                  <span className="text-text-muted text-sm font-medium">حالة الصندوق</span>
                  <span className={`font-bold px-3 py-1 rounded-lg shadow-input border-2 ${
                    project.status === 'completed' 
                      ? 'bg-accent-green/10 text-accent-green border-accent-green/50' 
                      : 'bg-primary/10 text-primary-400 border-primary/50'
                  }`}>
                    {project.status === 'completed' ? 'مكتمل' : 'نشط'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 glass rounded-xl border-2 border-primary/60 shadow-input">
                  <span className="text-text-muted text-sm font-medium">سياسة التوزيع</span>
                  <span className="font-bold text-text-primary drop-shadow-lg">{project.distributionPolicy}</span>
                </div>
              </div>

              {/* Calculator Section */}
              <div className="mb-6 p-5 glass rounded-xl border-2 border-primary/60 bg-gradient-to-br from-primary/5 to-accent-purple/5 shadow-card">
                <h3 className="text-lg font-bold text-text-primary mb-4 flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-gradient-to-br from-accent-purple to-primary-500">
                    <TrendingUp className="text-white" size={18} />
                  </div>
                  <span>الحاسبة</span>
                </h3>

                <div className="mb-4">
                  <label className="block text-slate-700 text-sm font-semibold mb-2">
                    العائد المتوقع على الاستثمار في الصندوق
                  </label>
                </div>

                {/* Input */}
                <div className="mb-4">
                  <label className="block text-text-secondary text-sm mb-2 font-medium">مبلغ الاستثمار</label>
                  <input
                    type="number"
                    value={investmentAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                    min={project.minimumAmount}
                    className="w-full px-4 py-3.5 glass border-2 border-primary/60 rounded-xl focus:border-primary focus:shadow-input-focus outline-none text-text-primary font-semibold transition-all shadow-input"
                    placeholder={formatCurrency(project.minimumAmount)}
                  />
                </div>

                {/* Results */}
                {investmentAmount && parseFloat(investmentAmount) >= project.minimumAmount && (
                  <div className="space-y-3 mt-4">
                    <div className="flex justify-between items-center p-3 glass rounded-lg border-2 border-primary/60 shadow-input">
                      <span className="text-text-muted text-sm">مبلغ الاستثمار</span>
                      <span className="font-bold text-text-primary flex items-center gap-1 drop-shadow-lg">
                        {formatCurrency(parseFloat(investmentAmount))} <RiyalSymbol size={14} className="text-primary-400 drop-shadow-lg" />
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 glass rounded-lg border-2 border-accent-green/60 shadow-input">
                      <span className="text-text-muted text-sm">العوائد</span>
                      <span className="font-bold text-accent-green flex items-center gap-1 drop-shadow-lg">
                        {formatCurrency(returns.total)} <RiyalSymbol size={14} />
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 glass rounded-lg border-2 border-primary/60 shadow-input">
                      <span className="text-text-muted text-sm">المدة</span>
                      <span className="font-bold text-text-primary">{project.durationMonths} شهر</span>
                    </div>
                    <div className="h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent my-3" />
                    <div className="flex justify-between items-center p-4 glass rounded-xl border-2 border-primary/30 bg-gradient-to-br from-primary/10 to-accent-purple/10">
                      <span className="text-text-primary font-bold">المبلغ الإجمالي</span>
                      <span className="text-2xl font-bold bg-gradient-to-r from-accent-purple to-primary-500 bg-clip-text text-transparent flex items-center gap-2">
                        {formatCurrency(parseFloat(investmentAmount) + returns.total)} <RiyalSymbol size={20} className="text-primary-400" />
                      </span>
                    </div>
                  </div>
                )}

                {/* Amount Slider */}
                <div className="mt-6">
                  <label className="block text-text-secondary text-sm mb-2 font-medium">مبلغ الإستثمار</label>
                  <input
                    type="range"
                    min={project.minimumAmount}
                    max={project.targetAmount > 1000000 ? 1000000 : project.targetAmount}
                    step={project.minimumAmount}
                    value={investmentAmount || project.minimumAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                    className="w-full h-2.5 bg-background-tertiary rounded-full appearance-none cursor-pointer accent-primary-500"
                    style={{
                      background: `linear-gradient(to right, rgb(139, 92, 246) 0%, rgb(59, 130, 246) ${((parseFloat(investmentAmount) - project.minimumAmount) / (1000000 - project.minimumAmount)) * 100}%, rgb(37, 43, 59) ${((parseFloat(investmentAmount) - project.minimumAmount) / (1000000 - project.minimumAmount)) * 100}%, rgb(37, 43, 59) 100%)`
                    }}
                  />
                </div>
              </div>

              {/* Investment Button */}
              <button
                onClick={() => setShowConfirmPopup(true)}
                disabled={
                  project.status === 'completed' ||
                  !investmentAmount ||
                  parseFloat(investmentAmount) < project.minimumAmount
                }
                className={`group relative w-full py-4 rounded-xl font-bold text-lg transition-all ${
                  project.status === 'completed' || !investmentAmount || parseFloat(investmentAmount) < project.minimumAmount
                    ? 'bg-background-tertiary border border-primary/10 text-secondary cursor-not-allowed'
                    : 'bg-primary text-background hover:shadow-glow-gold hover:scale-105'
                }`}
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  {project.status === 'completed' ? 'تم تحقيق الصندوق' : (
                    <>
                      <TrendingUp size={20} />
                      <span>استثمر الآن</span>
                    </>
                  )}
                </span>
              </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Popup */}
      {showConfirmPopup && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-scale">
          <div className="relative max-w-md w-full">
            <div className="absolute -inset-1 bg-primary rounded-2xl opacity-30 blur-2xl" />
            <div className="relative bg-background-secondary border-2 border-primary/70 rounded-2xl p-8 shadow-card-hover">
              <h3 className="text-2xl font-bold text-primary mb-4 text-center">
                تأكيد الاستثمار
              </h3>
              
              <div className="space-y-4 mb-6">
                <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                  <p className="text-text-muted text-sm mb-1">المشروع</p>
                  <p className="text-lg font-bold text-text-primary">{project.title}</p>
                </div>
                
                <div className="glass p-4 rounded-xl border-2 border-primary/60 shadow-input">
                  <p className="text-text-muted text-sm mb-1">مبلغ الاستثمار</p>
                  <p className="text-xl font-bold text-primary flex items-center gap-2">
                    {formatCurrency(parseFloat(investmentAmount))} <RiyalSymbol size={18} />
                  </p>
                </div>

                <div className="glass p-4 rounded-xl border-2 border-accent-green/60 shadow-input">
                  <p className="text-text-muted text-sm mb-1">العائد المتوقع</p>
                  <p className="text-xl font-bold text-accent-green flex items-center gap-2">
                    {formatCurrency(returns.total)} <RiyalSymbol size={18} />
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleInvestment}
                  disabled={investing}
                  className="flex-1 py-4 bg-primary text-background rounded-xl font-bold hover:shadow-glow-gold transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {investing ? 'جاري التنفيذ...' : 'تأكيد الاستثمار'}
                </button>
                <button
                  onClick={() => setShowConfirmPopup(false)}
                  disabled={investing}
                  className="flex-1 py-4 bg-background-tertiary border-2 border-primary/60 text-secondary hover:text-white rounded-xl font-bold hover:border-primary transition-all"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Popup */}
      {investmentSuccess && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-scale">
          <div className="relative max-w-md w-full">
            <div className="absolute -inset-1 bg-accent-green rounded-2xl opacity-30 blur-2xl" />
            <div className="relative bg-background-secondary border-2 border-accent-green/70 rounded-2xl p-8 shadow-card-hover text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-accent-green/20 border-2 border-accent-green flex items-center justify-center">
                <CheckCircle size={40} className="text-accent-green" />
              </div>
              
              <h3 className="text-2xl font-bold text-accent-green mb-3">
                تم الاستثمار بنجاح!
              </h3>
              
              <p className="text-text-secondary mb-6">
                تم إضافة استثمارك بنجاح. يمكنك متابعة استثماراتك من صفحة "استثماراتي"
              </p>

              <div className="flex gap-3">
                <Link href="/investments" className="flex-1">
                  <button className="w-full py-4 bg-accent-green text-background rounded-xl font-bold hover:shadow-glow-sm transition-all hover:scale-105">
                    عرض استثماراتي
                  </button>
                </Link>
                <button
                  onClick={() => setInvestmentSuccess(false)}
                  className="flex-1 py-4 bg-background-tertiary border-2 border-primary/60 text-secondary hover:text-white rounded-xl font-bold hover:border-primary transition-all"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
